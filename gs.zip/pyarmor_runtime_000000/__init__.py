# Pyarmor 8.5.12 (trial), 000000, 2024-11-11T07:24:20.733174
from .pyarmor_runtime import __pyarmor__
